// ==UserScript==
// @name         站酷网添加图片下载按钮
// @namespace    https://greasyfork.org/zh-CN/users/193133-pana
// @homepage     https://www.sailboatweb.com
// @version      2.4.3
// @description  添加下载原图按钮
// @author       pana
// @include      http*://www.zcool.com.cn/work/*
// @grant        none
// @require      https://cdn.bootcss.com/FileSaver.js/1.3.8/FileSaver.min.js
// @require      https://greasyfork.org/scripts/376157-downloadpic/code/downloadPic.js?version=733967
// ==/UserScript==

(function() {
	'use strict';
	const ZCOOL_VALUE = {
		GROUP_REG: /^(http:|https:)?\/\/img\.zcool\.cn\/[0-9a-z/\-_.]+\.(jpg|jpeg|png|bmp|gif)/i,
		DOWNLOAD_BTN: {
			ICON_URL: 'url(https://static.hellorf.com/v180817115700/hellorf/images/iconpic-r-cache-hover.svg)',
			BACKGROUND_COLOR: {
				MOUSE_LEAVE: 'rgba(0, 0, 0, 0.5)',
				MOUSE_ENTER: 'rgba(0, 0, 0, 0.8)'
			}
		}
	};
	var number_obj = new Download_Number_Obj();

	function update_Progress(_count_num, percent_complete, btn) {
		btn.innerText = this.getTextValue() + '(' + percent_complete + '%)'
	}
	function transfer_Complete(_count_num, btn) {
		btn.innerText = this.getTextValue() + '(100%)';
		btn.downloadCompleted();
		number_obj.addCompleted();
		$('p#progressBtn').text(number_obj.getProgressString())
	}
	function download_Start(_count, btn) {
		btn.innerText += '(...)';
		number_obj.addTotal();
		$("p#progressBtn").text(number_obj.getProgressString())
	}
	function add_Download_Btn(img_src, count) {
		let download_obj = new Download_Pic_Obj(img_src, count);
		let download_btn = download_obj.createDownloadBtn(download_Start, saveAs, update_Progress, transfer_Complete, {
			'position': 'absolute',
			'top': '30px',
			'left': '30px',
			'display': 'block',
			'border-radius': '4px',
			'text-align': 'center',
			'vertical-align': 'middle',
			'zoom': '1',
			'padding-left': '36px',
			'padding-right': '12px',
			'height': '28px',
			'color': '#fff',
			'font-size': '12px',
			'line-height': '28px',
			'background-color': ZCOOL_VALUE.DOWNLOAD_BTN.BACKGROUND_COLOR.MOUSE_LEAVE,
			'background-image': ZCOOL_VALUE.DOWNLOAD_BTN.ICON_URL,
			'background-repeat': 'no-repeat',
			'background-position': '13px center',
			'background-size': '16px 14px'
		}, function() {
			this.style.backgroundColor = ZCOOL_VALUE.DOWNLOAD_BTN.BACKGROUND_COLOR.MOUSE_ENTER
		}, function() {
			this.style.backgroundColor = ZCOOL_VALUE.DOWNLOAD_BTN.BACKGROUND_COLOR.MOUSE_LEAVE
		});
		return download_btn
	}
	function add_Download_All_Btn() {
		let download_div = document.createElement('div');
		download_div.className = 'sidebar-fixed_box collect-middle-icon';
		download_div.style.backgroundImage = 'url(https://static.hellorf.com/v180817115700/hellorf/images/iconpic-r-cache.svg)';
		download_div.addEventListener('click', function() {
			document.getElementById(DOWNLOAD_PIC.STRING.ID_NAME).click()
		});
		let download_all_obj = new Download_All_Pic_Obj();
		download_all_obj.setTextValue('');
		let download_all_btn = download_all_obj.createDownloadBtn(DOWNLOAD_PIC.STRING.CLASS_NAME);
		download_div.appendChild(download_all_btn);
		let download_p = document.createElement('p');
		download_p.className = 'sidebar-fixed_warm-prompt';
		download_p.innerText = DOWNLOAD_PIC.TEXT.DOWNLOAD_ALL;
		download_div.appendChild(download_p);
		return download_div
	}
	function add_Progress_Btn() {
		let progress_btn = document.createElement('div');
		progress_btn.id = 'divProgress';
		progress_btn.className = 'sidebar-fixed_box collect-middle-icon';
		progress_btn.style.backgroundImage = 'none';
		let p_text = document.createElement('p');
		p_text.id = 'progressText';
		p_text.className = 'sidebar-fixed_warm-prompt';
		p_text.innerText = '下载进度';
		progress_btn.appendChild(p_text);
		let p_btn = document.createElement('p');
		p_btn.id = 'progressBtn';
		p_btn.innerText = number_obj.getProgressString();
		$(p_btn).css({
			'text-align': 'center',
			'line-height': '50px',
		});
		progress_btn.appendChild(p_btn);
		return progress_btn
	}
	function pic_Init(c_num) {
		let work_img_group = $("div.work-show-box img");
		for (; c_num < work_img_group.length; c_num++) {
			work_img_group.eq(c_num).parent().css('position', 'relative');
			let work_img_src = work_img_group.eq(c_num).attr('src');
			work_img_src = ZCOOL_VALUE.GROUP_REG.exec(work_img_src)[0];
			work_img_group.eq(c_num).after(add_Download_Btn(work_img_src, c_num))
		}
		return c_num
	}
	function init() {
		let count_num = 0;
		count_num = pic_Init(count_num);
		let fixed_box = $('.details-sidebar-fixed-box');
		fixed_box.prepend(add_Progress_Btn());
		fixed_box.prepend(add_Download_All_Btn());
		let observer = new MutationObserver(function() {
			count_num = pic_Init(count_num)
		});
		let listener_container = document.querySelector("div.work-show-box");
		let option = {
			'childList': true
		};
		observer.observe(listener_container, option)
	}
	init()
})();