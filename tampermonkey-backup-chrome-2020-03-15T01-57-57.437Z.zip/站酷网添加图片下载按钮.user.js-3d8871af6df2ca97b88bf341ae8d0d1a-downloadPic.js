// ==UserScript==
// @name         downloadPic
// @namespace    https://greasyfork.org/zh-CN/users/193133-pana
// @homepage     https://www.sailboatweb.com
// @version      3.1.5
// @description  DOWNLOAD_PIC
// @author       pana
// @grant        none
// ==/UserScript==

const DOWNLOAD_PIC = {
	SYMBOL: {
		UNDERLINE: '_',
		DIVIDE: '/',
	},
	TEXT: {
		DOWNLOAD: '下载原图',
		DOWNLOAD_ALL: '下载全部原图',
		VIEW: '查看原图',
		COMPLETED: '下载完成',
	},
	STRING: {
		CLASS_NAME: 'download_pic',
		ALL_CLASS_NAME: 'download_all_pic',
		VIEW_CLASS_NAME: 'display_pic',
		ID_NAME: 'the_download_pic',
	},
	REG: {
		NAME: /[^/]+\.(jpg|jpeg|png|bmp|gif)/i,
		EXTENSION: /\.(jpg|jpeg|png|bmp|gif)/i
	},
	NUMBER: {
		CHROME_LIMIT: 10,
		SLEEP_UNIT: 2000,
	}
};
const COPY_TITLE = {
	TEXT: {
		LABEL: '复制标题',
		COMPLETED: '复制成功',
	},
	STRING: {
		CLASS_NAME: 'copyTitleBtn',
	},
	REG: {
		CLEANING: /[\\/*?<>"|:]/g,
		SPACE: /^\s+|\s$/g,
	}
};
class Button_Obj {
	constructor(text_value, class_name) {
		this.textValue = text_value;
		this.className = class_name
	}
	getTextValue() {
		return this.textValue
	}
	getClassName() {
		return this.className
	}
	setTextValue(text_value) {
		this.textValue = text_value
	}
	setClassName(class_name) {
		if (class_name) {
			this.className = class_name
		}
	}
	addClassName(class_name) {
		this.className = this.className + ' ' + class_name
	}
	typeofFunction(typeof_value) {
		if (typeof(typeof_value) === 'function') {
			return true
		} else {
			console.log(typeof_value + ' is not function.');
			return false
		}
	}
	typeofJQuery() {
		if (typeof(jQuery) === 'function') {
			return true
		} else {
			console.log('jQuery is not imported.');
			return false
		}
	}
	typeofChrome() {
		return (navigator.userAgent.indexOf('Chrome') !== -1)
	}
	typeofFirefox() {
		return (navigator.userAgent.indexOf('Firefox') !== -1)
	}
	sleep(ms, callback) {
		setTimeout(function() {
			console.log((ms / 1000) + ' second later.');
			callback()
		}, ms)
	}
	setButtonStyle(button, style_value) {
		if (typeof(style_value) === 'string') {
			button.setAttribute('style', style_value)
		} else if (typeof(style_value) === 'object') {
			if (this.typeofJQuery()) {
				$(button).css(style_value)
			}
		} else {
			console.log('style_value is ' + typeof(style_value))
		}
	}
	setMouseEvent(button, hover_over, hover_out) {
		if (this.typeofJQuery()) {
			if (this.typeofFunction(hover_over) && this.typeofFunction(hover_out)) {
				$(button).hover(hover_over, hover_out)
			}
		}
	}
	createBtn(target_value, button_title, css_value, hover_over, hover_out) {
		let button = document.createElement('a');
		button.target = target_value;
		button.title = button_title;
		button.href = 'javascript:;';
		button.className = this.className;
		button.innerText = this.textValue;
		if (css_value) {
			this.setButtonStyle(button, css_value)
		}
		if (hover_over && hover_out) {
			this.setMouseEvent(button, hover_over, hover_out)
		}
		return button
	}
}
class Download_Pic_Obj extends Button_Obj {
	constructor(download_address = '', count_value = -1, filename = '', text_value = DOWNLOAD_PIC.TEXT.DOWNLOAD, class_name = DOWNLOAD_PIC.STRING.CLASS_NAME) {
		super(text_value, class_name);
		this.countValue = count_value;
		download_address = download_address.replace('https:', '').replace('http:', '');
		this.downloadAddress = download_address;
		if ((filename === '') || (filename === undefined) || (filename === null)) {
			if (DOWNLOAD_PIC.REG.NAME.exec(download_address)) {
				this.filename = DOWNLOAD_PIC.REG.NAME.exec(download_address)[0]
			} else {
				this.filename = 'no-name.jpg'
			}
		} else {
			if (count_value > -1) {
				if (DOWNLOAD_PIC.REG.EXTENSION.exec(download_address)) {
					this.filename = filename + DOWNLOAD_PIC.SYMBOL.UNDERLINE + count_value + DOWNLOAD_PIC.REG.EXTENSION.exec(download_address)[0]
				} else {
					this.filename = filename + DOWNLOAD_PIC.SYMBOL.UNDERLINE + count_value + '.jpg'
				}
			} else {
				if (DOWNLOAD_PIC.REG.EXTENSION.exec(download_address)) {
					this.filename = filename + DOWNLOAD_PIC.REG.EXTENSION.exec(download_address)[0]
				} else {
					this.filename = filename + '.jpg'
				}
			}
		}
	}
	getDownloadAddress() {
		return this.downloadAddress
	}
	getCountValue() {
		return this.countValue
	}
	getFilename() {
		return this.filename
	}
	setFilename(filename = '') {
		if ((filename === '') || (filename === undefined) || (filename === null)) {
			if (DOWNLOAD_PIC.REG.NAME.exec(this.downloadAddress)) {
				this.filename = DOWNLOAD_PIC.REG.NAME.exec(this.downloadAddress)[0]
			} else {
				this.filename = 'no-name.jpg'
			}
		} else {
			if (this.countValue > -1) {
				if (DOWNLOAD_PIC.REG.EXTENSION.exec(this.downloadAddress)) {
					this.filename = filename + DOWNLOAD_PIC.SYMBOL.UNDERLINE + this.countValue + DOWNLOAD_PIC.REG.EXTENSION.exec(this.downloadAddress)[0]
				} else {
					this.filename = filename + DOWNLOAD_PIC.SYMBOL.UNDERLINE + this.countValue + '.jpg'
				}
			} else {
				if (DOWNLOAD_PIC.REG.EXTENSION.exec(this.downloadAddress)) {
					this.filename = filename + DOWNLOAD_PIC.REG.EXTENSION.exec(this.downloadAddress)[0]
				} else {
					this.filename = filename + '.jpg'
				}
			}
		}
	}
	setDownloadAddress(download_address = '', count_value = -1, filename = '') {
		download_address = download_address.replace('https:', '').replace('http:', '');
		this.downloadAddress = download_address;
		this.countValue = count_value;
		if ((filename === '') || (filename === undefined) || (filename === null)) {
			if (DOWNLOAD_PIC.REG.NAME.exec(download_address)) {
				this.filename = DOWNLOAD_PIC.REG.NAME.exec(download_address)[0]
			} else {
				this.filename = 'no-name.jpg'
			}
		} else {
			if (this.countValue > -1) {
				if (DOWNLOAD_PIC.REG.EXTENSION.exec(download_address)) {
					this.filename = filename + DOWNLOAD_PIC.SYMBOL.UNDERLINE + this.countValue + DOWNLOAD_PIC.REG.EXTENSION.exec(download_address)[0]
				} else {
					this.filename = filename + DOWNLOAD_PIC.SYMBOL.UNDERLINE + this.countValue + '.jpg'
				}
			} else {
				if (DOWNLOAD_PIC.REG.EXTENSION.exec(download_address)) {
					this.filename = filename + DOWNLOAD_PIC.REG.EXTENSION.exec(download_address)[0]
				} else {
					this.filename = filename + '.jpg'
				}
			}
		}
		return this.filename
	}
	createDownloadBtn(download_start, save_file, update_progress_callback, transfer_complete, css_value, hover_over, hover_out) {
		let download_btn = this.createBtn('_self', DOWNLOAD_PIC.TEXT.DOWNLOAD, css_value, hover_over, hover_out);
		download_btn.id = this.className + DOWNLOAD_PIC.SYMBOL.UNDERLINE + this.countValue;
		if (arguments.length > 0) {
			let that = this;
			if (this.typeofJQuery()) {
				$(download_btn).on('click', function(event) {
					event.stopPropagation();
					that.downloadHandle(download_start, save_file, update_progress_callback, transfer_complete, this)
				})
			} else {
				download_btn.addEventListener('click', function(event) {
					event.stopPropagation();
					that.downloadHandle(download_start, save_file, update_progress_callback, transfer_complete, this)
				})
			}
		}
		download_btn.downloadCompleted = function() {
			this.title = DOWNLOAD_PIC.TEXT.COMPLETED
		};
		return download_btn
	}
	downloadFile(save_file, update_progress_callback, transfer_complete, btn) {
		let that = this;
		let xhr = new XMLHttpRequest();
		xhr.addEventListener('progress', function(evt) {
			that.updateProgress(evt, update_progress_callback, btn)
		}, false);
		xhr.addEventListener('load', function() {
			if (that.typeofFunction(transfer_complete)) {
				transfer_complete.call(that, that.countValue, btn)
			}
		}, false);
		xhr.open('GET', this.downloadAddress, true);
		xhr.responseType = 'blob';
		xhr.onload = function() {
			if (xhr.status === 200) {
				if (that.typeofFunction(save_file)) {
					save_file(xhr.response, that.filename)
				}
			}
		};
		xhr.onerror = function() {
			that.downloadFile(save_file, update_progress_callback, transfer_complete, btn)
		};
		xhr.send()
	}
	updateProgress(evt, update_progress_callback, btn) {
		if (evt.lengthComputable) {
			let percent_complete = Math.round(evt.loaded * 100 / evt.total);
			if (this.typeofFunction(update_progress_callback)) {
				update_progress_callback.call(this, this.countValue, percent_complete, btn)
			}
		}
	}
	downloadHandle(download_start, save_file, update_progress_callback, transfer_complete, btn) {
		if (this.typeofFunction(download_start)) {
			download_start.call(this, this.countValue, btn)
		}
		this.downloadFile(save_file, update_progress_callback, transfer_complete, btn)
	}
}
class Download_All_Pic_Obj extends Button_Obj {
	constructor(id_name = DOWNLOAD_PIC.STRING.ID_NAME, filename = '', text_value = DOWNLOAD_PIC.TEXT.DOWNLOAD_ALL, class_name = DOWNLOAD_PIC.STRING.ALL_CLASS_NAME) {
		super(text_value, class_name);
		this.filename = filename;
		this.idName = id_name
	}
	getIdName() {
		return this.idName
	}
	getFilename() {
		return this.filename
	}
	setIdName(id_name = DOWNLOAD_PIC.STRING.ID_NAME) {
		if (id_name) {
			this.idName = id_name
		}
	}
	setFilename(filename = '') {
		this.filename = filename
	}
	createDownloadBtn(class_name_args, css_value, hover_over, hover_out) {
		let download_all_btn = this.createBtn('_self', DOWNLOAD_PIC.TEXT.DOWNLOAD_ALL, css_value, hover_over, hover_out);
		download_all_btn.id = this.idName;
		let that = this;
		if ((typeof(class_name_args) === 'string') && class_name_args) {
			if (this.typeofJQuery()) {
				$(download_all_btn).on('click', function(event) {
					event.stopPropagation();
					let download_btn_obj = $('.' + class_name_args);
					for (let i = 0; i < download_btn_obj.length; i++) {
						if (that.typeofChrome()) {
							let parse_i = parseInt(i / DOWNLOAD_PIC.NUMBER.CHROME_LIMIT);
							if (parse_i > 0) {
								that.sleep(parse_i * DOWNLOAD_PIC.NUMBER.SLEEP_UNIT, function() {
									download_btn_obj.eq(i)[0].click()
								});
								continue
							}
						}
						download_btn_obj.eq(i)[0].click()
					}
				})
			} else {
				download_all_btn.addEventListener('click', function(event) {
					event.stopPropagation();
					let download_btn_dom = document.getElementsByClassName(class_name_args);
					for (let j = 0; j < download_btn_dom.length; j++) {
						if (that.typeofChrome()) {
							let parse_j = parseInt(j / DOWNLOAD_PIC.NUMBER.CHROME_LIMIT);
							if (parse_j > 0) {
								that.sleep(parse_j * DOWNLOAD_PIC.NUMBER.SLEEP_UNIT, function() {
									download_btn_dom[j].click()
								});
								continue
							}
						}
						download_btn_dom[j].click()
					}
				})
			}
		} else {
			console.log('class_name_args is error.')
		}
		return download_all_btn
	}
	createDownloadAllBtn(array_args, download_start, save_file, update_progress_callback, transfer_complete, css_value, hover_over, hover_out) {
		let download_all_btn = this.createBtn('_self', DOWNLOAD_PIC.TEXT.DOWNLOAD_ALL, css_value, hover_over, hover_out);
		download_all_btn.id = this.idName;
		if (typeof(array_args) === 'object') {
			let temp_obj_array = [];
			for (let k = 0; k < array_args.length; k++) {
				let temp_obj = new Download_Pic_Obj(array_args[k], k + 1, this.filename);
				temp_obj_array.push(temp_obj)
			}
			let that = this;
			if (this.typeofJQuery()) {
				$(download_all_btn).on('click', function(event) {
					event.stopPropagation();
					for (let l = 0; l < temp_obj_array.length; l++) {
						if (that.typeofChrome()) {
							let parse_l = parseInt(l / DOWNLOAD_PIC.NUMBER.CHROME_LIMIT);
							if (parse_l > 0) {
								that.sleep(parse_l * DOWNLOAD_PIC.NUMBER.SLEEP_UNIT, function() {
									temp_obj_array[l].downloadHandle(download_start, save_file, update_progress_callback, transfer_complete)
								});
								continue
							}
						}
						temp_obj_array[l].downloadHandle(download_start, save_file, update_progress_callback, transfer_complete)
					}
				})
			} else {
				download_all_btn.addEventListener('click', function(event) {
					event.stopPropagation();
					for (let m = 0; m < temp_obj_array.length; m++) {
						if (that.typeofChrome()) {
							let parse_m = parseInt(m / DOWNLOAD_PIC.NUMBER.CHROME_LIMIT);
							if (parse_m > 0) {
								that.sleep(parse_m * DOWNLOAD_PIC.NUMBER.SLEEP_UNIT, function() {
									temp_obj_array[m].downloadHandle(download_start, save_file, update_progress_callback, transfer_complete)
								});
								continue
							}
						}
						temp_obj_array[m].downloadHandle(download_start, save_file, update_progress_callback, transfer_complete)
					}
				})
			}
		} else {
			console.log('array_args is error.')
		}
		return download_all_btn
	}
}
class Display_Pic_Obj extends Button_Obj {
	constructor(pic_link = '', text_value = DOWNLOAD_PIC.TEXT.VIEW, class_name = DOWNLOAD_PIC.STRING.VIEW_CLASS_NAME) {
		super(text_value, class_name);
		this.picLink = pic_link
	}
	getPicLink() {
		return this.picLink
	}
	setPicLink(pic_link = '') {
		if (pic_link) {
			this.picLink = pic_link
		}
	}
	createDisplayBtn(css_value, hover_over, hover_out, display_start) {
		let display_btn = this.createBtn('_blank', DOWNLOAD_PIC.TEXT.VIEW, css_value, hover_over, hover_out);
		display_btn.href = this.picLink;
		if (arguments.length === 4) {
			let that = this;
			if (this.typeofFunction(display_start)) {
				if (this.typeofJQuery()) {
					$(display_btn).on('mousedown', function(event) {
						event.stopPropagation();
						display_start.call(that, this)
					})
				} else {
					display_btn.addEventListener('mousedown', function(event) {
						event.stopPropagation();
						display_start.call(that, this)
					})
				}
			}
		}
		return display_btn
	}
	displayHandle(display_start) {
		if (this.typeofFunction(display_start)) {
			display_start.call(this)
		}
		window.open(this.picLink)
	}
}
class Copy_Title_Obj extends Button_Obj {
	constructor(copy_text, text_value = COPY_TITLE.TEXT.LABEL, class_name = COPY_TITLE.STRING.CLASS_NAME) {
		super(text_value, class_name);
		copy_text = copy_text.replace(COPY_TITLE.REG.CLEANING, ' ');
		copy_text = copy_text.replace(COPY_TITLE.REG.SPACE, '');
		this.copyText = copy_text
	}
	getCopyText() {
		return this.copyText
	}
	setCopyText(copy_text) {
		copy_text = copy_text.replace(COPY_TITLE.REG.CLEANING, ' ');
		copy_text = copy_text.replace(COPY_TITLE.REG.SPACE, '');
		this.copyText = copy_text
	}
	createCopyBtn(css_value, copy_completed, copy_function, hover_over, hover_out) {
		let copy_btn = this.createBtn('_self', COPY_TITLE.TEXT.LABEL, css_value, hover_over, hover_out);
		if (arguments.length > 1) {
			let that = this;
			if (this.typeofJQuery()) {
				$(copy_btn).on('click', function(event) {
					event.stopPropagation();
					that.copyHandle(copy_completed, copy_function, this)
				})
			} else {
				copy_btn.addEventListener('click', function(event) {
					event.stopPropagation();
					that.copyHandle(copy_completed, copy_function, this)
				})
			}
		}
		copy_btn.copyCompleted = function() {
			this.title = COPY_TITLE.TEXT.COMPLETED
		};
		return copy_btn
	}
	copyHandle(copy_completed, copy_function, btn) {
		if (this.typeofFunction(copy_function)) {
			copy_function(this.copyText, "text")
		} else {
			let o_input = document.createElement('input');
			o_input.value = this.copyText;
			document.body.appendChild(o_input);
			o_input.select();
			document.execCommand("Copy");
			o_input.className = 'oInput';
			o_input.style.display = 'none'
		}
		if (this.typeofFunction(copy_completed)) {
			copy_completed.call(this, btn)
		}
	}
}
class Download_Number_Obj {
	constructor(total = 0, completed = 0) {
		this.total = total;
		this.completed = completed
	}
	addTotal(num = 1) {
		this.total += num
	}
	addCompleted(num = 1) {
		this.completed += num
	}
	decTotal(num = 1) {
		this.total -= num
	}
	decCompleted(num = 1) {
		this.completed -= num
	}
	getTotal() {
		return this.total
	}
	getCompleted() {
		return this.completed
	}
	setTotal(num = 0) {
		this.total = num
	}
	setCompleted(num = 0) {
		this.completed = num
	}
	getProgressString(connection = DOWNLOAD_PIC.SYMBOL.DIVIDE) {
		return this.completed + connection + this.total
	}
}