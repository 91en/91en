// ==UserScript==
// @namespace zyxubing
// @name Aria2下载助手
// @description This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @version 0.3.3.1
// @include https://pan.baidu.com/*
// @include https://yun.baidu.com/*
// @include https://wallhaven.cc/*
// @include https://www.bilibili.com/video/av*
// @include https://www.bilibili.com/bangumi/play/*
// @include https://live.bilibili.com/*
// @include https://space.bilibili.com/*
// @include https://search.bilibili.com/*
// @include https://nyaa.fun/*
// @include https://nyaa.si/*
// @include https://sukebei.nyaa.si/*
// @include https://nyaa.mlyx.workers.dev/*
// @include https://acg.rip/*
// @domain baidu.com
// @domain baidupcs.com
// @domain bilibili.com
// @domain 111.229.137.150
// @domain 127.0.0.1
// @domain localhost
// @domain self
// @grant GM_cookie
// @grant GM_setClipboard
// @grant GM_xmlhttpRequest
// @run-at document-idle
// ==/UserScript==
